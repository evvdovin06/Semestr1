﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Desktop
{
    /// <summary>
    /// Логика взаимодействия для AddTask.xaml
    /// </summary>
    public partial class AddTask : Window
    {
        public AddTask()
        {
            InitializeComponent();
        }

        public TaskModel NewTask { get; set; }

        private void confirmButton_Click(object sender, RoutedEventArgs e)
        {
            NewTask = new TaskModel
            {
                Title = titleTB.Text,
                Category = (categoryCB.SelectedItem as ComboBoxItem).Content.ToString(),
                Date = dateP.SelectedDate.Value,
                Time = timeTB.Text,
                Description = descTB.Text,
                IsCompleted = false,
            };
            this.DialogResult = true;
        }
    }
}