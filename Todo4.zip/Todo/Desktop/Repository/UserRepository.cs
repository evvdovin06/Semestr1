﻿using System;
using System.Collections.Generic;
using System.Linq;
using TodoEntities;
using System.Text;
using System.Threading.Tasks;


namespace Desktop.Repository
{
    internal class UserRepository
    {
        private static List<UserModel> _users = new List<UserModel>()
        {
        new UserModel {Email = "exam@mail.ru",  Name = "Admin", Password = "123456"}
        };

        public UserModel GetUser(string email, string password)
        {
            return _users.FirstOrDefault(user => user.Email == email && user.Password == password);
        }

        public bool RegisterUser(string username, string useremail, string password)
        {

            if (_users.Exists(u => u.Email.Equals(useremail, StringComparison.OrdinalIgnoreCase)))
            {
                return false;
            }


            _users.Add(new UserModel { Name = username, Email = useremail, Password = password });

            return true;
        }

        public UserModel AuthenticateUser(string useremail, string username, string password)
        {
            return _users.FirstOrDefault(user =>
                user.Email == useremail && user.Name == username && user.Password == password);
        }
    }
}
