﻿using Desktop.Repository;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace Desktop
{
    /// <summary>
    /// Логика взаимодействия для Page.xaml
    /// </summary>
    public partial class Page : Window
    {
        private string _username;

        public string UserName
        {
            get => _username;
            set
            {
                _username = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<TaskModel> Tasks { get; set; }

        public ObservableCollection<TaskModel> CompletedTasks { get; set; }

        private UserRepository _userRepository;
        public Page()
        {

            InitializeComponent();

            if (UserRepository.CurrentUser != null)
            {
                username.Text = UserRepository.CurrentUser.Name;
            }

            Tasks = new ObservableCollection<TaskModel>();
            CompletedTasks = new ObservableCollection<TaskModel>();
            DataContext = this;
        }

        private void UpdateTaskFields(TaskModel task)
        {
            if (task != null)
            {
                taskTitleTextBlock.Text = task.Title;
                taskDescriptionTextBlock.Text = task.Description;
                taskTimeTextBlock.Text = task.Time;
                taskDateTextBlock.Text = task.Date.ToString("d MMMM yyyy");
            }
            else
            {
                ClearTaskFields();
            }
        }

        private void ClearTaskFields()
        {
            taskTitleTextBlock.Text = string.Empty;
            taskDescriptionTextBlock.Text = string.Empty;
            taskDateTextBlock.Text = string.Empty;
            taskTimeTextBlock.Text = string.Empty;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private void FilterHistory(object sender, RoutedEventArgs e)
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(Tasks);

            view.Filter = item =>
            {
                if (item is TaskModel task)
                {
                    return task.IsCompleted == true;
                }
                return false;
            };
        }

        private void taskListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            deleteButton.Visibility = Visibility.Visible;
            okButton.Visibility = Visibility.Visible;
            border.Visibility = Visibility.Visible;

            TaskModel selectedTask = (TaskModel)taskListBox.SelectedItem;
            UpdateTaskFields(selectedTask);
        }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            deleteButton.Visibility = Visibility.Collapsed;
            okButton.Visibility = Visibility.Collapsed;
            border.Visibility = Visibility.Collapsed;

            TaskModel selectedTask = (TaskModel)taskListBox.SelectedItem;

            if (selectedTask != null)
            {
                Tasks.Remove(selectedTask);
                CompletedTasks.Add(selectedTask);
            }

            taskListBox.Items.Refresh();
            taskListBox_History.Items.Refresh();
        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (taskListBox.SelectedItem is TaskModel selectedTask)
            {
                Tasks.Remove(selectedTask);
            }

            if (taskListBox_History.SelectedItem is TaskModel selectedTask_2)
            {
                CompletedTasks.Remove(selectedTask_2);
            }

            deleteButton.Visibility = Visibility.Collapsed;
            okButton.Visibility = Visibility.Collapsed;
            border.Visibility = Visibility.Collapsed;

            taskListBox.Items.Refresh();
            taskListBox_History.Items.Refresh();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var add = new AddTask();

            if (add.ShowDialog() == true && add.NewTask != null)
            {
                Tasks.Add(add.NewTask);
                taskListBox.Items.Refresh();
                taskListBox_History.Items.Refresh();
            }
        }

        private void homeFilterButton_Click(object sender, RoutedEventArgs e)
        {
            deleteButton.Visibility = Visibility.Collapsed;
            okButton.Visibility = Visibility.Collapsed;
            border.Visibility = Visibility.Collapsed;
            ClearTaskFields();

            var button = sender as Button;
            string category = button.Content.ToString();
            taskListBox.ItemsSource = Tasks.Where(t => t.Category == category).ToList();

            taskListBox_History.ItemsSource = CompletedTasks.Where(t => t.Category == category).ToList();
        }

        private void history_Button_Click(object sender, RoutedEventArgs e)
        {
            taskListBox.Visibility = Visibility.Collapsed;
            taskListBox_History.Visibility = Visibility.Visible;

            deleteButton.Visibility = Visibility.Collapsed;
            okButton.Visibility = Visibility.Collapsed;
            border.Visibility = Visibility.Collapsed;
            ClearTaskFields();

            taskListBox_History.ItemsSource = CompletedTasks;
        }

        private void tasks_Button_Click(object sender, RoutedEventArgs e)
        {
            taskListBox_History.Visibility = Visibility.Collapsed;
            taskListBox.Visibility = Visibility.Visible;

            deleteButton.Visibility = Visibility.Collapsed;
            okButton.Visibility = Visibility.Collapsed;
            border.Visibility = Visibility.Collapsed;
            ClearTaskFields();

            taskListBox.ItemsSource = Tasks;
        }

        private void taskListBox_History_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            deleteButton.Visibility = Visibility.Visible;
            border.Visibility = Visibility.Visible;

            TaskModel selectedTask = (TaskModel)taskListBox_History.SelectedItem;
            UpdateTaskFields(selectedTask);
        }
    }
}
