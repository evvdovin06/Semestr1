﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desktop
{
    public class TaskModel
    {
        public string Category { get; set; }
        public bool IsCompleted { get; set; }
        public string Title { get; set; }
        public DateTime Date { get; set; }
        public string Time { get; set; }
        public string Description { get; set; }
        public bool Visibility { get; set; }
        public int id { get; set; }
    }
}