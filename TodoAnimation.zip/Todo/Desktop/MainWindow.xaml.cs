﻿using Desktop.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Desktop
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1 Window1 = new Window1();

         
            DoubleAnimation fadeOut = new DoubleAnimation
            {
                From = 1.0,
                To = 0.0,
                Duration = TimeSpan.FromSeconds(0.5)
            };

            fadeOut.Completed += (s, _) =>
            {
                this.Hide(); 
               
                Window1.Opacity = 0;
                Window1.Show();

                DoubleAnimation fadeIn = new DoubleAnimation
                {
                    From = 0.0,
                    To = 1.0,
                    Duration = TimeSpan.FromSeconds(0.5)
                };

                Window1.BeginAnimation(UIElement.OpacityProperty, fadeIn);
            };

          
            this.BeginAnimation(UIElement.OpacityProperty, fadeOut);

        }
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
    
            DoubleAnimation fadeInAnimation = new DoubleAnimation
            {
                From = 0,    
                To = 1,     
                Duration = TimeSpan.FromSeconds(3) 
            };

            Label1.BeginAnimation(UIElement.OpacityProperty, fadeInAnimation);

            // Начальное положение (над видимой областью)
            Button1.RenderTransform = new TranslateTransform(0, -100);
            Button1.Opacity = 0;

            // Анимация прозрачности
            DoubleAnimation fadeIn = new DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = TimeSpan.FromSeconds(1)
            };

            // Анимация движения
            DoubleAnimation slideDown = new DoubleAnimation
            {
                From = -100,
                To = 0,
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new BounceEase { Bounces = 2, Bounciness = 3 }
            };

            // Запускаем обе анимации
            Button1.BeginAnimation(UIElement.OpacityProperty, fadeIn);
            Button1.RenderTransform.BeginAnimation(TranslateTransform.YProperty, slideDown);
        }
    


        private void RemoveText(object sender, RoutedEventArgs e)
        {
            TextBox instance = (TextBox)sender;
            if (instance.Text == instance.Tag.ToString())
                instance.Text = "";
            instance.Opacity = 1;
        }

        private void AddText(object sender, RoutedEventArgs e)
        {
            TextBox instance = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(instance.Text))
                instance.Text = instance.Tag.ToString();
            instance.Opacity = 0.4;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string email = emailTB.Text;
            string password = passwordTB.Text;

            if (!email.ValidateEmail())
            {
                // error
                MessageBox.Show("Некорректная почта");
                return;
            }

            if (!password.ValidatePassword())
            {
                MessageBox.Show("Пароль должен содержать 6 символов или более");
                return;
            }

            if (email.ValidateEmail() && password.ValidatePassword())
            {
                var userRep = new UserRepository();
                var user = userRep.GetUser(emailTB.Text, passwordTB.Text);

                if (user != null)
                {
                    MessageBox.Show($"Вход выполнен успешно!");
                    Page main = new Page();
                    main.Show();
                    this.Hide();
                }

                else
                {
                    MessageBox.Show("Неверный email или пароль");
                }
            }
        }
    }
}
